This folder should contain node-red-contrib nodes specific to this project.
They can be referenced by the package.json hosted in the /data folder.